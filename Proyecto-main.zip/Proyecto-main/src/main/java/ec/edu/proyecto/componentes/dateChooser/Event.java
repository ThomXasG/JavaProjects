/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.proyecto.componentes.dateChooser;

import java.awt.event.MouseEvent;

/**
 *
 * @author Asus
 */
public interface Event {

    public void execute(MouseEvent evt, int num);
}
