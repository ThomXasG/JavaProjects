/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.proyecto.conexion;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author Asus
 */
public class Conexion {
    private Connection conexion = null;
    
    public Connection conectar(){
        String url = "jdbc:mysql://localhost:3306/visual";
        String user = "root";
        String password = "admin";
        try{
            conexion = DriverManager.getConnection(url,user, password);
        }catch(Exception e){
            System.out.println(e);
        }
        return conexion;
    }
}
