/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.proyecto.datos;

import ec.edu.proyecto.conexion.Conexion;
import ec.edu.proyecto.domain.Asistencia;
import ec.edu.proyecto.utilidades.FuncionesVentanas;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Asus
 */
public class AsistenciaDTO {

    private final Conexion conexion = new Conexion();
    private final Connection conectar = conexion.conectar();
    private final String SQL_JORNADA = "SELECT idAsistencia, tipoEvento, hora, tipoAsistencia, minutosAtraso, multa "
            + "from asistencias "
            + "WHERE cedula in "
            + "( SELECT cedula FROM empleados WHERE correo = ? ) AND jornada = ? AND fecha = ? order by hora";
    private final String SQL_CEDULA = "SELECT cedula FROM empleados WHERE correo = ?";
    private final String SQL_ASISTENCIA = "INSERT INTO ASISTENCIAS (cedula, fecha, tipoEvento, hora) VALUES "
            + "(?, ?, ? ,?)";
    private final String SQL_COMPROBAR_REGISTRO = "SELECT COUNT(*) as cuenta FROM asistencias WHERE jornada = ? AND "
            + "tipoEvento = 'entrada' and fecha = ? and cedula = ( SELECT cedula FROM empleados WHERE correo = ? )";

    public ArrayList<Asistencia> obtenerAsistencias(String correo, String jornada, String fecha) {
        ArrayList<Asistencia> registros = new ArrayList<>();
        try {
            PreparedStatement statement = conectar.prepareStatement(SQL_JORNADA);
            statement.setString(1, correo);
            statement.setString(2, jornada);
            statement.setString(3, fecha);

            ResultSet resultado = statement.executeQuery();
            while (resultado.next()) {
                int idAsistencia = resultado.getInt("idAsistencia");
                String tipoEvento = resultado.getString("tipoEvento");
                String hora = resultado.getString("hora");
                String tipoAsistencia = resultado.getString("tipoAsistencia");
                int minutosAtraso = resultado.getInt("minutosAtraso");
                double multa = resultado.getDouble("multa");
                registros.add(new Asistencia(idAsistencia, tipoEvento, hora, tipoAsistencia, minutosAtraso, multa));
            }
        } catch (SQLException ex) {
            FuncionesVentanas.mensaje(null, ex.getMessage());
        }
        return registros;
    }
    
    private String obtenerCedula(String correo){
        String cedula = "";
        try{
            PreparedStatement statement = conectar.prepareStatement(SQL_CEDULA);
            statement.setString(1, correo);
            
            ResultSet resultado = statement.executeQuery();
            if(resultado.next()){
                cedula = resultado.getString("cedula");
            }
        }catch (SQLException ex) {
            FuncionesVentanas.mensaje(null, ex.getMessage());
        }
        return cedula;
    }
    
    public int registrarAsistencia(String correo, String fecha, String tipo, String hora ){
        int n = 0;
        try{
            PreparedStatement statement = conectar.prepareStatement(SQL_ASISTENCIA);
            statement.setString(1, obtenerCedula(correo));
            statement.setString(2, fecha);
            statement.setString(3, tipo);
            statement.setString(4, hora);
            n = statement.executeUpdate();
        }catch (SQLException ex) {
            FuncionesVentanas.mensaje(null, ex.getMessage());
        }
        return n;
    }
    
    public int comprobarRegistros(String jornada, String fecha, String correo) {
        int n = 0;
        try {
            PreparedStatement statement = conectar.prepareStatement(SQL_COMPROBAR_REGISTRO);
            statement.setString(1, jornada);
            statement.setString(2, fecha);
            statement.setString(3, correo);
            ResultSet result = statement.executeQuery();
            if (result.next()) {
                n = result.getInt("cuenta");
            }
        } catch (SQLException ex) {
            FuncionesVentanas.mensaje(null, ex.getMessage());
        }
        return n;
    }
}
