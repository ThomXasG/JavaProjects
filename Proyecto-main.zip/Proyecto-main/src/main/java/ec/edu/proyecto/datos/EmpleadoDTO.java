/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.proyecto.datos;

import ec.edu.proyecto.conexion.Conexion;
import ec.edu.proyecto.domain.Empleado;
import ec.edu.proyecto.utilidades.FuncionesVentanas;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
/**
 *
 * @author Asus
 */
public class EmpleadoDTO {

    private final Conexion conexion = new Conexion();
    private final Connection conectar = conexion.conectar();
    private final String SQL_INSERT = "CALL InsertarUsuarioEmpleado (?,?,?,?,?,?,?,?,?)";
    private final String SQL_UPDATE = "UPDATE empleados SET primerNombre = ?, segundoNombre = ?, primerApellido = ?,"
            + " segundoApellido = ? WHERE correo = ? ";
    private final String SQL_UPDATE_PASS = "CALL  ActualizarUsuarioYEmpleado (?,?,?,?,?,?)";
    private final String SQL_DELETE = "UPDATE usuarios set estado = 'Inactivo' WHERE correo = ?";
    private final String SQL_OBTENER_NOMBRE = """
                                              SELECT CONCAT(primerNombre, ' ', segundoNombre, ' ', primerApellido, ' ', segundoApellido) AS nombre
                                              FROM empleados WHERE correo = ?""";
    private final String SQL_OBTENER_CEDULA = "SELECT cedula FROM empleados WHERE correo = ?";
    private final String SQL_OBTENER_ID = "SELECT idDigital FROM empleados WHERE correo = ?";

    public int insertarEmpleado(Empleado empleado) {
        int n = 0;
        try {
            PreparedStatement statement = conectar.prepareStatement(SQL_INSERT);
            statement.setString(1, empleado.getCedula());
            statement.setString(2, empleado.getCorreo());
            statement.setString(3, empleado.getContrasenia());
            statement.setString(4, empleado.getRol());
            statement.setString(5, empleado.getPrimerNombre());
            statement.setString(6, empleado.getSegundoNombre());
            statement.setString(7, empleado.getPrimerApellido());
            statement.setString(8, empleado.getSegundoApellido());
            statement.setString(9, empleado.getIdDigital());
            n = statement.executeUpdate();
            return n;
        } catch (SQLException ex) {
            if (ex instanceof SQLIntegrityConstraintViolationException) {
                FuncionesVentanas.mensaje(null, "Ya existe el empleado");
            } else {
                FuncionesVentanas.mensaje(null, ex.getMessage());
            }
        }
        return -1;
    }

    public int editarEmpleado(Empleado empleado) {
        int n = 0;
        try {
            PreparedStatement statement = conectar.prepareStatement(SQL_UPDATE);
            statement.setString(1, empleado.getPrimerNombre());
            statement.setString(2, empleado.getSegundoNombre());
            statement.setString(3, empleado.getPrimerApellido());
            statement.setString(4, empleado.getSegundoApellido());
            statement.setString(5, empleado.getCorreo());
            n = statement.executeUpdate();
        } catch (SQLException ex) {
            FuncionesVentanas.mensaje(null, ex.getMessage());
        }
        return n;
    }

    public int editarEmpleadoCon(Empleado empleado) {
        int n = 0;
        try {
            PreparedStatement statement = conectar.prepareStatement(SQL_UPDATE_PASS);
            statement.setString(1, empleado.getCorreo());
            statement.setString(2, empleado.getContrasenia());
            statement.setString(3, empleado.getPrimerNombre());
            statement.setString(4, empleado.getSegundoNombre());
            statement.setString(5, empleado.getPrimerApellido());
            statement.setString(6, empleado.getSegundoApellido());
            n = statement.executeUpdate();
        } catch (SQLException ex) {
            FuncionesVentanas.mensaje(null, ex.getMessage());
        }
        return n;
    }

    public int eliminarEmpleado(String correo) {
        int n = 0;
        try {
            PreparedStatement statement = conectar.prepareStatement(SQL_DELETE);
            statement.setString(1, correo);
            n = statement.executeUpdate();
        } catch (SQLException ex) {
            FuncionesVentanas.mensaje(null, ex.getMessage());
        }
        return n;
    }

    public String obtenerNombre(String correo) {
        String nombre = "";
        try {
            PreparedStatement statement = conectar.prepareStatement(SQL_OBTENER_NOMBRE);
            statement.setString(1, correo);

            ResultSet resultado = statement.executeQuery();
            if (resultado.next()) {
                nombre = resultado.getString("nombre");
            }
        } catch (SQLException ex) {
            FuncionesVentanas.mensaje(null, ex.getMessage());
        }
        return nombre;
    }

    public String obtenerCedula(String correo) {
        String cedula = "";
        try {
            PreparedStatement statement = conectar.prepareStatement(SQL_OBTENER_CEDULA);
            statement.setString(1, correo);

            ResultSet resultado = statement.executeQuery();
            if (resultado.next()) {
                cedula = resultado.getString("cedula");
            }
        } catch (SQLException ex) {
            FuncionesVentanas.mensaje(null, ex.getMessage());
        }
        return cedula;
    }
    
    public String obtenerIDigital(String correo) {
        String id = "";
        try {
            PreparedStatement statement = conectar.prepareStatement(SQL_OBTENER_ID);
            statement.setString(1, correo);

            ResultSet resultado = statement.executeQuery();
            if (resultado.next()) {
                id = resultado.getString("idDigital");
            }
        } catch (SQLException ex) {
            FuncionesVentanas.mensaje(null, ex.getMessage());
        }
        return id;
    }
    
}
