/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.proyecto.domain;

/**
 *
 * @author Asus
 */
public class Asistencia {
    private int id;
    private String tipoEvento;
    private String hora;
    private String tipoAsistencia;
    private int minutosAtraso;

    public int getMinutosAtraso() {
        return minutosAtraso;
    }

    public void setMinutosAtraso(int minutosAtraso) {
        this.minutosAtraso = minutosAtraso;
    }
    private double multa;

    public Asistencia(int id, String tipoEvento, String hora, String tipoAsistencia, int minutosAtraso, double multa) {
        this.id = id;
        this.tipoEvento = tipoEvento;
        this.hora = hora;
        this.tipoAsistencia = tipoAsistencia;
        this.minutosAtraso = minutosAtraso;
        this.multa = multa;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTipoEvento() {
        return tipoEvento;
    }

    public void setTipoEvento(String tipoEvento) {
        this.tipoEvento = tipoEvento;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getTipoAsistencia() {
        return tipoAsistencia;
    }

    public void setTipoAsistencia(String tipoAsistencia) {
        this.tipoAsistencia = tipoAsistencia;
    }

    public double getMulta() {
        return multa;
    }

    public void setMulta(double multa) {
        this.multa = multa;
    }

    
}
