/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.proyecto.domain;

/**
 *
 * @author Asus
 */
public class Empleado extends Usuario {

    private String cedula;
    private String rol;
    private String primerNombre;
    private String segundoNombre;
    private String primerApellido;
    private String segundoApellido;
    private String idDigital;

    public Empleado(String correo, String contrasenia) {
        super(correo, contrasenia);
    }

    public Empleado(String correo, String contrasenia, String cedula, String primerNombre, String segundoNombre, String primerApellido, String segundoApellido, String idDigital) {
        super(correo, contrasenia);
        this.cedula = cedula;
        this.rol = "Empleado";
        this.primerNombre = primerNombre;
        this.segundoNombre = segundoNombre;
        this.primerApellido = primerApellido;
        this.segundoApellido = segundoApellido;
        this.idDigital = idDigital;
    }

    public Empleado(String correo, String contrasenia, String primerNombre, String segundoNombre, String primerApellido, String segundoApellido) {
        super(correo, contrasenia);
        this.primerNombre = primerNombre;
        this.segundoNombre = segundoNombre;
        this.primerApellido = primerApellido;
        this.segundoApellido = segundoApellido;
    }

    public Empleado(String correo ,String primerNombre, String segundoNombre, String primerApellido, String segundoApellido) {
        super(correo);
        this.primerNombre = primerNombre;
        this.segundoNombre = segundoNombre;
        this.primerApellido = primerApellido;
        this.segundoApellido = segundoApellido;
    }

    public String getRol() {
        return rol;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getPrimerNombre() {
        return primerNombre;
    }

    public void setPrimerNombre(String primerNombre) {
        this.primerNombre = primerNombre;
    }

    public String getSegundoNombre() {
        return segundoNombre;
    }

    public void setSegundoNombre(String segundoNombre) {
        this.segundoNombre = segundoNombre;
    }

    public String getPrimerApellido() {
        return primerApellido;
    }

    public void setPrimerApellido(String primerApellido) {
        this.primerApellido = primerApellido;
    }

    public String getSegundoApellido() {
        return segundoApellido;
    }

    public void setSegundoApellido(String segundoApellido) {
        this.segundoApellido = segundoApellido;
    }

    public String getIdDigital() {
        return idDigital;
    }

    public void setIdDigital(String idDigital) {
        this.idDigital = idDigital;
    }

}
