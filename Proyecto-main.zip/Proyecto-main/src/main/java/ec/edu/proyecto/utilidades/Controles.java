/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.proyecto.utilidades;

import java.awt.event.KeyEvent;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JTextField;

/**
 *
 * @author Asus
 */
public class Controles {

    public static boolean camposVacios(String... campos) {
        for (String campo : campos) {
            if (campo.isEmpty()) {
                return false;
            }
        }
        return true;
    }

    public static boolean validarCorreo(String correo) {
        String patronCorreo = "^[A-Za-z0-9+_.-]+@asistency\\.com$";
        Pattern pattern = Pattern.compile(patronCorreo);
        Matcher matcher = pattern.matcher(correo);
        return matcher.matches();
    }

    public static boolean validarCedula(String numeroCedula) {
//        int suma = 0;
//        if (numeroCedula.length() != 10 || Integer.parseInt(numeroCedula.substring(0, 2)) > 24 || Integer.parseInt(numeroCedula.substring(0, 2)) < 0 || Integer.parseInt(String.valueOf(numeroCedula.charAt(2))) > 6) {
//            return false;
//        } else {
//            int[] a = new int[numeroCedula.length() / 2];
//            int[] b = new int[(numeroCedula.length() / 2)];
//            int c = 0;
//            int d = 1;
//            for (int i = 0; i < numeroCedula.length() / 2; i++) {
//                a[i] = Integer.parseInt(String.valueOf(numeroCedula.charAt(c)));
//                c = c + 2;
//                if (i < (numeroCedula.length() / 2) - 1) {
//                    b[i] = Integer.parseInt(String.valueOf(numeroCedula.charAt(d)));
//                    d = d + 2;
//                }
//            }
//            for (int i = 0; i < a.length; i++) {
//                a[i] = a[i] * 2;
//                if (a[i] > 9) {
//                    a[i] = a[i] - 9;
//                }
//                suma = suma + a[i] + b[i];
//            }
//            int aux = suma / 10;
//            int dec = (aux + 1) * 10;
//            if ((dec - suma) == Integer.parseInt(String.valueOf(numeroCedula.charAt(numeroCedula.length() - 1)))) {
//                return true;
//            } else if (suma % 10 == 0 && numeroCedula.charAt(numeroCedula.length() - 1) == '0') {
//                return true;
//            } else {
//                return false;
//            }
//        }
        return true;
    }

    public static void validarLetras(java.awt.event.KeyEvent evt, JTextField campo) {
        char c = evt.getKeyChar();
        if (!Character.isLetter(c) && c != KeyEvent.VK_BACK_SPACE || campo.getText().length() > 35 ) {
            evt.consume();
        }
    }
}
