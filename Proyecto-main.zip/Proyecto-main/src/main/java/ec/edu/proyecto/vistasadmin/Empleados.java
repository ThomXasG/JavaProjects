/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package ec.edu.proyecto.vistasadmin;

import com.formdev.flatlaf.intellijthemes.materialthemeuilite.FlatMaterialLighterIJTheme;
import ec.edu.proyecto.componentes.SearchOptinEvent;
import ec.edu.proyecto.componentes.SearchOption;
import ec.edu.proyecto.componentes.confirmation.MessageDialog;
import ec.edu.proyecto.conexion.Conexion;
import ec.edu.proyecto.datos.EmpleadoDTO;
import ec.edu.proyecto.domain.Empleado;
import ec.edu.proyecto.utilidades.Controles;
import ec.edu.proyecto.utilidades.FuncionesVentanas;
import java.awt.Color;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.DefaultTableModel;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.view.JasperViewer;

/**
 *
 * @author Asus
 */
public class Empleados extends javax.swing.JPanel {

    DefaultTableModel modelo;
    EmpleadoDTO empleadoD = new EmpleadoDTO();

    /**
     * Creates new form Empleados
     */
    public Empleados() {
        initComponents();
        FlatMaterialLighterIJTheme.setup();
        txt.addEventOptionSelected(new SearchOptinEvent() {
            @Override
            public void optionSelected(SearchOption option, int index) {
                txt.setHint("Busque por " + option.getName() + "...");
            }
        });
        txt.addOption(new SearchOption("Cedula", new ImageIcon(getClass().getResource("/ced.png"))));
        txt.addOption(new SearchOption("Nombres", new ImageIcon(getClass().getResource("/user.png"))));
        txt.addOption(new SearchOption("Correo", new ImageIcon(getClass().getResource("/cor.png"))));
        txt.setSelectedIndex(0);
        cargarDatos("");
        datos.getSelectionModel().addListSelectionListener((ListSelectionEvent e) -> {
            if (datos.getSelectedRow() != -1) {
                int fila = datos.getSelectedRow();
                jtxtNom.setText(datos.getValueAt(fila, 2).toString());
                jtxtNom1.setText(datos.getValueAt(fila, 3).toString());
                jtxtApe.setText(datos.getValueAt(fila, 4).toString());
                jtxtApe1.setText(datos.getValueAt(fila, 5).toString());
            }
        });
    }
    public void meses(){
        DefaultComboBoxModel<String> modelo = new DefaultComboBoxModel<>();
        modelo.addElement("Meses");
        for (int i = 1; i <= 12; i++) {
            modelo.addElement(String.valueOf(i));
        }
        jcbxMes.setModel(modelo);
    }

    public void eliminarEmpleado(String correo) {
        if (empleadoD.eliminarEmpleado(correo) > 0) {
            FuncionesVentanas.mensaje(this, "Se elimino el empleado");
            cargarDatos("");
            borrarCampos();
        } else {
            FuncionesVentanas.mensaje(this, "Ocurrio un error al eliminar el empleado");
        }
    }

    public void borrarCampos() {
        jtxtNom.setText("");
        jtxtNom1.setText("");
        jtxtApe.setText("");
        jtxtApe1.setText("");
        jtxtCon.setText("");
        jtxtCon1.setText("");
    }

    public boolean controles() {
        String primerNombre = jtxtNom.getText();
        String segundoNombre = jtxtNom1.getText();
        String primerApe = jtxtApe.getText();
        String segundoApe = jtxtApe1.getText();
        if (!Controles.camposVacios(primerNombre, segundoNombre, primerApe, segundoApe)) {
            FuncionesVentanas.mensaje(this, "Llene todos los campos");
            return false;
        }
        return true;
    }

    public void actualizarEmpleado(Empleado empleado) {
        if (empleadoD.editarEmpleado(empleado) > 0) {
            FuncionesVentanas.mensaje(this, "Se ha editado al empleado");
            cargarDatos("");
        } else {
            FuncionesVentanas.mensaje(this, "Ha ocurrido un error");
        }
    }

    public void actualizarEmpleadoCon(Empleado empleado) {
        if (empleadoD.editarEmpleadoCon(empleado) > 0) {
            FuncionesVentanas.mensaje(this, "Se ha editado al empleado");
            cargarDatos("");
        } else {
            FuncionesVentanas.mensaje(this, "Ha ocurrido un error");
        }
    }

    private void cargarDatos(String where, String... search) {
        try {
            Conexion conexion = new Conexion();
            Connection conectar = conexion.conectar();
            String titulos[] = {"Cedula", "Correo", "Primer Nombre", "Segundo Nombre", "Primer Apellido", "Segundo Apellido"};
            PreparedStatement pr = conectar.prepareStatement("select cedula, correo, primerNombre, segundoNombre"
                    + ", primerApellido, segundoApellido from empleados where  correo in (select correo from usuarios where estado = \"activo\")"
                    + where);
            modelo = new DefaultTableModel(null, titulos);
            for (int i = 0; i < search.length; i++) {
                pr.setObject(i + 1, search[i]);
            }
            ResultSet rs = pr.executeQuery();
            while (rs.next()) {
                String cedula = rs.getString("cedula");
                String correo = rs.getString("correo");
                String primerNombre = rs.getString("primerNombre");
                String segundoNombre = rs.getString("segundoNombre");
                String primerApellido = rs.getString("primerApellido");
                String segundoApellido = rs.getString("segundoApellido");
                Object[] datos = {cedula, correo, primerNombre, segundoNombre, primerApellido, segundoApellido};
                modelo.addRow(datos);
            }
            datos.setModel(modelo);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jtxtNom = new ec.edu.proyecto.componentes.TextField();
        jtxtNom1 = new ec.edu.proyecto.componentes.TextField();
        jtxtApe = new ec.edu.proyecto.componentes.TextField();
        jtxtApe1 = new ec.edu.proyecto.componentes.TextField();
        jbtnActualizar = new javax.swing.JButton();
        jbtnReporte = new javax.swing.JButton();
        jbtnEliminar = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        datos = new javax.swing.JTable();
        txt = new ec.edu.proyecto.componentes.TextFieldSearchOption();
        jbtnCancelar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jtxtCon = new ec.edu.proyecto.componentes.PasswordField();
        jtxtCon1 = new ec.edu.proyecto.componentes.PasswordField();
        jcbxMes = new javax.swing.JComboBox<>();

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jtxtNom.setLabelText("Primer Nombre");
        jtxtNom.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jtxtNomKeyTyped(evt);
            }
        });

        jtxtNom1.setLabelText("Segundo Nombre");
        jtxtNom1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jtxtNom1KeyTyped(evt);
            }
        });

        jtxtApe.setLabelText("Primer Apellido");
        jtxtApe.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jtxtApeKeyTyped(evt);
            }
        });

        jtxtApe1.setLabelText("Segundo Apellido");
        jtxtApe1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jtxtApe1KeyTyped(evt);
            }
        });

        jbtnActualizar.setBackground(new java.awt.Color(32, 175, 232));
        jbtnActualizar.setFont(new java.awt.Font("Roboto", 1, 16)); // NOI18N
        jbtnActualizar.setForeground(new java.awt.Color(255, 255, 255));
        jbtnActualizar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/act.png"))); // NOI18N
        jbtnActualizar.setText("Actualizar");
        jbtnActualizar.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 20, 1, 1, new java.awt.Color(0, 0, 0)));
        jbtnActualizar.setBorderPainted(false);
        jbtnActualizar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jbtnActualizar.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jbtnActualizar.setIconTextGap(10);
        jbtnActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnActualizarActionPerformed(evt);
            }
        });

        jbtnReporte.setBackground(new java.awt.Color(32, 175, 232));
        jbtnReporte.setFont(new java.awt.Font("Roboto", 1, 16)); // NOI18N
        jbtnReporte.setForeground(new java.awt.Color(255, 255, 255));
        jbtnReporte.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rep.png"))); // NOI18N
        jbtnReporte.setText("Reporte");
        jbtnReporte.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 20, 1, 1, new java.awt.Color(0, 0, 0)));
        jbtnReporte.setBorderPainted(false);
        jbtnReporte.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jbtnReporte.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jbtnReporte.setIconTextGap(10);
        jbtnReporte.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnReporteActionPerformed(evt);
            }
        });

        jbtnEliminar.setBackground(new java.awt.Color(32, 175, 232));
        jbtnEliminar.setFont(new java.awt.Font("Roboto", 1, 16)); // NOI18N
        jbtnEliminar.setForeground(new java.awt.Color(255, 255, 255));
        jbtnEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/del.png"))); // NOI18N
        jbtnEliminar.setText("Eliminar");
        jbtnEliminar.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 20, 1, 1, new java.awt.Color(0, 0, 0)));
        jbtnEliminar.setBorderPainted(false);
        jbtnEliminar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jbtnEliminar.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jbtnEliminar.setIconTextGap(10);
        jbtnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnEliminarActionPerformed(evt);
            }
        });

        datos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(datos);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 710, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        txt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtKeyReleased(evt);
            }
        });

        jbtnCancelar.setBackground(new java.awt.Color(32, 175, 232));
        jbtnCancelar.setFont(new java.awt.Font("Roboto", 1, 16)); // NOI18N
        jbtnCancelar.setForeground(new java.awt.Color(255, 255, 255));
        jbtnCancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/can.png"))); // NOI18N
        jbtnCancelar.setText("Cancelar");
        jbtnCancelar.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 20, 1, 1, new java.awt.Color(0, 0, 0)));
        jbtnCancelar.setBorderPainted(false);
        jbtnCancelar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jbtnCancelar.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jbtnCancelar.setIconTextGap(10);
        jbtnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnCancelarActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 102, 102));
        jLabel1.setText("* Campos obligatorios");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 102, 102));
        jLabel2.setText("*");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 102, 102));
        jLabel3.setText("*");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 102, 102));
        jLabel4.setText("*");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 102, 102));
        jLabel5.setText("*");

        jtxtCon.setLabelText("Contraseña");

        jtxtCon1.setLabelText("Confirmar Contraseña");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(txt, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(90, 90, 90)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jcbxMes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(23, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jtxtNom, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel5))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jtxtApe, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jtxtNom1, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jtxtApe1, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jbtnActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jtxtCon, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jbtnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jbtnReporte, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jtxtCon1, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jbtnCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(48, 48, 48))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jtxtNom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jtxtApe1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel5)
                    .addComponent(jbtnActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jtxtNom1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3)
                            .addComponent(jtxtCon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jtxtApe, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4)
                            .addComponent(jtxtCon1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jbtnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jbtnCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jbtnReporte, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(txt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(jcbxMes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jbtnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnActualizarActionPerformed
        if (!controles()) {
            return;
        }
        int fila = datos.getSelectedRow();
        String primerNombre = jtxtNom.getText();
        String segundoNombre = jtxtNom1.getText();
        String primerApe = jtxtApe.getText();
        String segundoApe = jtxtApe1.getText();
        String correo = datos.getValueAt(fila, 1).toString();
        Empleado empleado = new Empleado(correo, primerNombre, segundoNombre, primerApe, segundoApe);
        String pass = String.valueOf(jtxtCon.getPassword());
        String pass1 = String.valueOf(jtxtCon1.getPassword());
        if (pass.isEmpty() && pass1.isEmpty()) {
            actualizarEmpleado(empleado);
        } else if ((!pass.isEmpty() || !pass1.isEmpty()) && !pass.equals(pass1)) {
            FuncionesVentanas.mensaje(this, "Las contraseñas no coinciden");
        } else {
            Empleado empleadoCon = new Empleado(correo, pass, primerNombre, segundoNombre, primerApe, segundoApe);
            actualizarEmpleadoCon(empleadoCon);
        }
    }//GEN-LAST:event_jbtnActualizarActionPerformed

    private void jbtnReporteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnReporteActionPerformed
        // TODO add your handling code here:
        if (txt.getText() != null && jcbxMes.getSelectedIndex() != 0) {
            String path = "D:\\DESCARGAS\\Proyecto-main\\src\\main\\java\\ec\\edu\\proyecto\\reportes.Empleado.jrxml";
            try {
                Conexion cc = new Conexion();
                JasperCompileManager.compileReportToFile(path);
                Map<String, Object> parametros = new HashMap<>();
                //Aca van los parametros
                parametros.put("ced", txt.getText());
                parametros.put("mes", jcbxMes.getSelectedItem().toString());
                JasperPrint jasperPrint
                        = JasperFillManager.fillReport(
                                "D:\\DESCARGAS\\Proyecto-main\\src\\main\\java\\ec\\edu\\proyecto\\reportes.Empleado.jasper",
                                parametros, cc.conectar());
                JasperViewer.viewReport(jasperPrint, false);
            } catch (JRException e) {
            }
        }
        else{
            JOptionPane.showMessageDialog(this, "Los parametros no deben estar vacios");
        }
    }//GEN-LAST:event_jbtnReporteActionPerformed

    private void jbtnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnEliminarActionPerformed
        // TODO add your handling code here:
        if (!controles()) {
            return;
        }
        int fila = datos.getSelectedRow();
        String correo = datos.getValueAt(fila, 1).toString();
        UIManager.put("OptionPane.background", Color.WHITE);
        UIManager.put("Panel.background", Color.WHITE);
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException | UnsupportedLookAndFeelException e) {
            FuncionesVentanas.mensaje(this, e.getMessage());
        }
        MessageDialog mensaje = new MessageDialog(this);
        mensaje.showMessage("Eliminar Empleado", "¿Esta seguro de que quiere eliminar al empleado?");
        if (mensaje.getMessageType() == MessageDialog.MessageType.OK) {
            eliminarEmpleado(correo);
            FlatMaterialLighterIJTheme.setup();
        } else {
            FlatMaterialLighterIJTheme.setup();
        }
    }//GEN-LAST:event_jbtnEliminarActionPerformed

    private void jbtnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnCancelarActionPerformed
        // TODO add your handling code here:
        borrarCampos();
    }//GEN-LAST:event_jbtnCancelarActionPerformed

    private void txtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtKeyReleased
        // TODO add your handling code here:
        if (txt.isSelected()) {
            String text = "%" + txt.getText() + "%";
            int option = txt.getSelectedIndex();
            if (option == 0) {
                cargarDatos("and cedula like ? ", text);
            } else if (option == 1) {
                cargarDatos("and (primerNombre like ? or segundoNombre like ? or primerApellido like ?"
                        + " or segundoApellido like ?)", text, text, text, text);
            } else if (option == 2) {
                cargarDatos("and correo like ? ", text);
            }
        }
    }//GEN-LAST:event_txtKeyReleased

    private void jtxtNomKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtNomKeyTyped
        Controles.validarLetras(evt, jtxtNom);
    }//GEN-LAST:event_jtxtNomKeyTyped

    private void jtxtNom1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtNom1KeyTyped
        // TODO add your handling code here:
        Controles.validarLetras(evt, jtxtNom1);
    }//GEN-LAST:event_jtxtNom1KeyTyped

    private void jtxtApeKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtApeKeyTyped
        Controles.validarLetras(evt, jtxtApe);
    }//GEN-LAST:event_jtxtApeKeyTyped

    private void jtxtApe1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtApe1KeyTyped
        Controles.validarLetras(evt, jtxtApe1);
    }//GEN-LAST:event_jtxtApe1KeyTyped


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable datos;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton jbtnActualizar;
    private javax.swing.JButton jbtnCancelar;
    private javax.swing.JButton jbtnEliminar;
    private javax.swing.JButton jbtnReporte;
    private javax.swing.JComboBox<String> jcbxMes;
    private ec.edu.proyecto.componentes.TextField jtxtApe;
    private ec.edu.proyecto.componentes.TextField jtxtApe1;
    private ec.edu.proyecto.componentes.PasswordField jtxtCon;
    private ec.edu.proyecto.componentes.PasswordField jtxtCon1;
    private ec.edu.proyecto.componentes.TextField jtxtNom;
    private ec.edu.proyecto.componentes.TextField jtxtNom1;
    private ec.edu.proyecto.componentes.TextFieldSearchOption txt;
    // End of variables declaration//GEN-END:variables
}
