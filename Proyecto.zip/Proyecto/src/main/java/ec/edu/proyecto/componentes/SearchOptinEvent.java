/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package ec.edu.proyecto.componentes;

/**
 *
 * @author Asus
 */
public interface SearchOptinEvent {

    public void optionSelected(SearchOption option, int index);
}
