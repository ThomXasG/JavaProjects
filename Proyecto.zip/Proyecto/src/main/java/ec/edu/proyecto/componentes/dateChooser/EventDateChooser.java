/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.proyecto.componentes.dateChooser;

/**
 *
 * @author Asus
 */
public interface EventDateChooser {
    public void dateSelected(SelectedAction action, SelectedDate date);
}
