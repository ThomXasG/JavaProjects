/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.proyecto.datos;

import ec.edu.proyecto.conexion.Conexion;
import ec.edu.proyecto.domain.Administrador;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import javax.swing.JOptionPane;

/**
 *
 * @author Asus
 */
public class AdministradorDTO {

    private final Conexion conexion = new Conexion();
    private final Connection conectar = conexion.conectar();
    private final String SQL_INSERT = "INSERT INTO usuarios (correo, contrasenia) VALUES (?,?)";

    public int ingresarAdministrador(Administrador administrador) {
        int n = 0;
        try {
            PreparedStatement statement = conectar.prepareStatement(SQL_INSERT);
            statement.setString(1, administrador.getCorreo());
            statement.setString(2, administrador.getContrasenia());
            n = statement.executeUpdate();
        } catch (SQLException ex) {
            if (ex instanceof SQLIntegrityConstraintViolationException) {
                JOptionPane.showMessageDialog(null, "Ya existe el administrador");
            } else {
                JOptionPane.showMessageDialog(null, ex);
            }
        }
        return n;
    }
}
