/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.proyecto.datos;

import ec.edu.proyecto.conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Asus
 */
public class UsuarioDTO {

    private final Conexion conexion = new Conexion();
    private final Connection conectar = conexion.conectar();
    private final String SQL_SELECT = "SELECT rol FROM usuarios WHERE correo = ? AND contrasenia = ?";
    private final String SQL_OBTENER = "SELECT marca FROM marcaAsis WHERE correo = ?";
    private final String SQL_MARCAR = "UPDATE marcaAsis set marca = ? WHERE correo = ?";

    public String verificarLogin(String correo, String contrasenia) {
        String rol = "norol";
        try {
            PreparedStatement preparedStatement = conectar.prepareStatement(SQL_SELECT);
            preparedStatement.setString(1, correo);
            preparedStatement.setString(2, contrasenia);
            ResultSet result = preparedStatement.executeQuery();

            if (result.next()) {
                rol = result.getString("rol");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
        return rol;
    }

    public String verMarca(String correo) {
        String marca  = "";
        try {
            PreparedStatement preparedStatement = conectar.prepareStatement(SQL_OBTENER);
            preparedStatement.setString(1, correo);
            ResultSet result = preparedStatement.executeQuery();
            if (result.next()) {
                marca = result.getString("marca");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
        return marca;
    }

    public int actualizarMarca(String marca, String correo) {
        int n = 0;
        try {
            PreparedStatement preparedStatement = conectar.prepareStatement(SQL_MARCAR);
            preparedStatement.setString(1, marca);
            preparedStatement.setString(2, correo);
            n = preparedStatement.executeUpdate();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
        return n;
    }
}
