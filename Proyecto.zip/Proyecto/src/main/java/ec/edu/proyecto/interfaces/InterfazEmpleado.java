/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package ec.edu.proyecto.interfaces;

import com.formdev.flatlaf.intellijthemes.materialthemeuilite.FlatMaterialLighterIJTheme;
import ec.edu.proyecto.componentes.dateChooser.SelectedDate;
import ec.edu.proyecto.datos.AsistenciaDTO;
import ec.edu.proyecto.datos.EmpleadoDTO;
import ec.edu.proyecto.datos.UsuarioDTO;
import ec.edu.proyecto.domain.Asistencia;
import ec.edu.proyecto.utilidades.FuncionesVentanas;
import java.time.LocalTime;
import java.time.ZonedDateTime;
import java.time.format.TextStyle;
import java.util.Locale;
import javax.swing.ImageIcon;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Asus
 */
public class InterfazEmpleado extends javax.swing.JFrame {

    EmpleadoDTO empleado = new EmpleadoDTO();
    UsuarioDTO usuarioDTO = new UsuarioDTO();
    AsistenciaDTO asistencia = new AsistenciaDTO();
    DefaultTableModel modelo;
    private String correo = "eje2@asistency.com";

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public InterfazEmpleado() {
        this.setTitle("Asistency");
        this.setIconImage(new ImageIcon(getClass().getResource("/ic.png")).getImage());
        initComponents();
        horaActual();
        cargarDatos();
        cargarJornada();
        cambiarEstado();
    }

    public InterfazEmpleado(String correo) {
        this.correo = correo;
        this.setTitle("Asistency");
        this.setIconImage(new ImageIcon(getClass().getResource("/ic.png")).getImage());
        initComponents();
        horaActual();
        cargarDatos();
        cargarJornada();
        cambiarEstado();
    }

    private void cambiarEstado() {
        if (!Boolean.parseBoolean(usuarioDTO.verMarca(this.correo))) {
            jbtnRegistro.setText("Registrar asistencia");
        } else {
            jbtnRegistro.setText("Registrar salida");
        }
    }

    private String obtenerHoraActual2() {
        ZonedDateTime zonedDateTime = FuncionesVentanas.obtenerFechaHora();
        String hora = String.valueOf(zonedDateTime.getHour());
        String minuto = String.valueOf(zonedDateTime.getMinute());
        String segundo = String.valueOf(zonedDateTime.getSecond());
        minuto = (Integer.parseInt(minuto) < 10) ? "0" + minuto : minuto;
        segundo = (Integer.parseInt(segundo) < 10) ? "0" + segundo : segundo;

        String horaActual = hora + ":" + minuto + ":" + segundo;
        return horaActual;
    }

    private LocalTime obtenerHoraActual() {
        ZonedDateTime zonedDateTime = FuncionesVentanas.obtenerFechaHora();
        LocalTime hora = zonedDateTime.toLocalTime();
        return hora;
    }

    private String obtenerFechaActual() {
        ZonedDateTime zonedDateTime = FuncionesVentanas.obtenerFechaHora();
        String anio = String.valueOf(zonedDateTime.getYear());
        String mes = String.valueOf(zonedDateTime.getMonthValue());
        String dia = String.valueOf(zonedDateTime.getDayOfMonth());
        return anio + "-" + mes + "-" + dia;
    }

    private void horaActual() {
        Thread hiloHora;
        hiloHora = new Thread(() -> {
            while (true) {
                ZonedDateTime zonedDateTime = FuncionesVentanas.obtenerFechaHora();
                String hora = String.valueOf(zonedDateTime.getHour());
                String minuto = String.valueOf(zonedDateTime.getMinute());
                String segundo = String.valueOf(zonedDateTime.getSecond());
                minuto = (Integer.parseInt(minuto) < 10) ? "0" + minuto : minuto;
                segundo = (Integer.parseInt(segundo) < 10) ? "0" + segundo : segundo;

                String horaActual = hora + ":" + minuto + ":" + segundo;

                SwingUtilities.invokeLater(() -> {
                    jhora.setText(horaActual);
                });

                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    FuncionesVentanas.mensaje(rootPane, e.getMessage());
                }
            }
        });
        hiloHora.start();
    }

    private String obtenerJornada() {
        ZonedDateTime zonedDateTime = FuncionesVentanas.obtenerFechaHora();
        int hora = zonedDateTime.getHour();
        String jornada;
        if (hora > 7 && hora < 13) {
            jornada = "Jornada Matutina";
        } else {
            jornada = "Jornada Vespertina";
        }
        return jornada;
    }

    private String horaTrabajo() {
        String horario;
        if (obtenerJornada().equals("Jornada Matutina")) {
            horario = "08am - 13pm";
        } else {
            horario = "14pm - 17pm";
        }
        return horario;
    }
    
    private String jornada() {
        ZonedDateTime zonedDateTime = FuncionesVentanas.obtenerFechaHora();
        int hora = zonedDateTime.getHour();
        String jornada;
        if (hora > 7 && hora < 13) {
            jornada = "mañana";
        } else {
            jornada = "tarde";
        }
        return jornada;
    }

    private void cargarDatos() {
        ZonedDateTime zonedDateTime = FuncionesVentanas.obtenerFechaHora();
        String diaSemana = zonedDateTime.getDayOfWeek().getDisplayName(TextStyle.FULL, new Locale("es", "ES"));
        String titulos[] = {"DIA", "NOMBRE", "CEDULA", "JORNADA", "HORARIO"};
        Object data[] = {diaSemana, empleado.obtenerNombre(this.correo), empleado.obtenerCedula(correo),
            obtenerJornada(), horaTrabajo()
        };
        modelo = new DefaultTableModel(null, titulos);
        modelo.addRow(data);
        jtblDatos.setModel(modelo);
    }

    private void cargarJornadas(JTable tabla, String jornada, String fecha) {
        String titulos[] = {"ID", "TIPO REGISTRO", "HORA REGISTRO", "TIPO ASISTENCIA", "MINUTOS ATRASO", "MULTA"};
        modelo = new DefaultTableModel(null, titulos);
        for (Asistencia asist : this.asistencia.obtenerAsistencias(this.correo,
                jornada, fecha)) {
            Object data[] = {asist.getId(), asist.getTipoEvento(), asist.getHora(),
                asist.getTipoAsistencia(), asist.getMinutosAtraso(), asist.getMulta()};
            modelo.addRow(data);
        }
        tabla.setModel(modelo);
    }

    private void cargarJornada() {
        cargarJornadas(jtblJornada1, "Mañana", obtenerFechaActual());
        cargarJornadas(jtblJornada2, "Tarde", obtenerFechaActual());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        date = new ec.edu.proyecto.componentes.dateChooser.DateChooser();
        bg = new javax.swing.JPanel();
        time = new javax.swing.JPanel();
        jhora = new javax.swing.JLabel();
        jbtnCancelar = new javax.swing.JButton();
        jbtnRegistro = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtblDatos = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jtblJornada2 = new javax.swing.JTable();
        jScrollPane3 = new javax.swing.JScrollPane();
        jtblJornada1 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jtxtDate = new javax.swing.JTextField();
        jbtnCerrar = new javax.swing.JButton();
        jbtnBuscar = new javax.swing.JButton();
        jbtnFecha = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jbtnReporteEmpleado1 = new javax.swing.JButton();

        date.setTextRefernce(jtxtDate);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        bg.setBackground(new java.awt.Color(32, 115, 216));

        time.setBackground(new java.awt.Color(255, 255, 255));
        time.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jhora.setFont(new java.awt.Font("Roboto", 1, 80)); // NOI18N
        jhora.setForeground(new java.awt.Color(0, 0, 0));
        jhora.setText("12:14:25");

        javax.swing.GroupLayout timeLayout = new javax.swing.GroupLayout(time);
        time.setLayout(timeLayout);
        timeLayout.setHorizontalGroup(
            timeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(timeLayout.createSequentialGroup()
                .addGap(149, 149, 149)
                .addComponent(jhora, javax.swing.GroupLayout.PREFERRED_SIZE, 326, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(159, Short.MAX_VALUE))
        );
        timeLayout.setVerticalGroup(
            timeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, timeLayout.createSequentialGroup()
                .addContainerGap(32, Short.MAX_VALUE)
                .addComponent(jhora, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29))
        );

        jbtnCancelar.setBackground(new java.awt.Color(255, 102, 102));
        jbtnCancelar.setFont(new java.awt.Font("Roboto", 1, 24)); // NOI18N
        jbtnCancelar.setForeground(new java.awt.Color(255, 255, 255));
        jbtnCancelar.setText("Cancelar");
        jbtnCancelar.setBorder(null);
        jbtnCancelar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jbtnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnCancelarActionPerformed(evt);
            }
        });

        jbtnRegistro.setBackground(new java.awt.Color(32, 175, 232));
        jbtnRegistro.setFont(new java.awt.Font("Roboto", 1, 24)); // NOI18N
        jbtnRegistro.setForeground(new java.awt.Color(255, 255, 255));
        jbtnRegistro.setText("Registrar Asistencia");
        jbtnRegistro.setBorder(null);
        jbtnRegistro.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jbtnRegistro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnRegistroActionPerformed(evt);
            }
        });

        jtblDatos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jtblDatos);

        jLabel1.setBackground(new java.awt.Color(32, 175, 232));
        jLabel1.setFont(new java.awt.Font("Roboto", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Jornadas de registro ");

        jtblJornada2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jtblJornada2);

        jtblJornada1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane3.setViewportView(jtblJornada1);

        jLabel2.setFont(new java.awt.Font("Roboto", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Vespertina");

        jLabel3.setFont(new java.awt.Font("Roboto", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Matutina");

        jtxtDate.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        jbtnCerrar.setBackground(new java.awt.Color(32, 175, 232));
        jbtnCerrar.setFont(new java.awt.Font("Roboto", 1, 16)); // NOI18N
        jbtnCerrar.setForeground(new java.awt.Color(255, 255, 255));
        jbtnCerrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/salida.png"))); // NOI18N
        jbtnCerrar.setText("Cerrar Sesion");
        jbtnCerrar.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 20, 1, 1, new java.awt.Color(0, 0, 0)));
        jbtnCerrar.setBorderPainted(false);
        jbtnCerrar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jbtnCerrar.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jbtnCerrar.setIconTextGap(10);
        jbtnCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnCerrarActionPerformed(evt);
            }
        });

        jbtnBuscar.setBackground(new java.awt.Color(26, 87, 172));
        jbtnBuscar.setFont(new java.awt.Font("Roboto", 1, 16)); // NOI18N
        jbtnBuscar.setForeground(new java.awt.Color(255, 255, 255));
        jbtnBuscar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/lu.png"))); // NOI18N
        jbtnBuscar.setText("Buscar");
        jbtnBuscar.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 20, 1, 1, new java.awt.Color(0, 0, 0)));
        jbtnBuscar.setBorderPainted(false);
        jbtnBuscar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jbtnBuscar.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jbtnBuscar.setIconTextGap(10);
        jbtnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnBuscarActionPerformed(evt);
            }
        });

        jbtnFecha.setBackground(new java.awt.Color(32, 115, 216));
        jbtnFecha.setForeground(new java.awt.Color(32, 115, 216));
        jbtnFecha.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cal.png"))); // NOI18N
        jbtnFecha.setBorder(null);
        jbtnFecha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnFechaActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Roboto", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Filtar Por Fecha");

        jbtnReporteEmpleado1.setBackground(new java.awt.Color(26, 87, 172));
        jbtnReporteEmpleado1.setFont(new java.awt.Font("Roboto", 1, 16)); // NOI18N
        jbtnReporteEmpleado1.setForeground(new java.awt.Color(255, 255, 255));
        jbtnReporteEmpleado1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/rep.png"))); // NOI18N
        jbtnReporteEmpleado1.setText("Reporte");
        jbtnReporteEmpleado1.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 20, 1, 1, new java.awt.Color(0, 0, 0)));
        jbtnReporteEmpleado1.setBorderPainted(false);
        jbtnReporteEmpleado1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jbtnReporteEmpleado1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jbtnReporteEmpleado1.setIconTextGap(10);
        jbtnReporteEmpleado1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnReporteEmpleado1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout bgLayout = new javax.swing.GroupLayout(bg);
        bg.setLayout(bgLayout);
        bgLayout.setHorizontalGroup(
            bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bgLayout.createSequentialGroup()
                .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(bgLayout.createSequentialGroup()
                        .addGap(222, 222, 222)
                        .addComponent(time, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(bgLayout.createSequentialGroup()
                        .addGap(228, 228, 228)
                        .addComponent(jbtnRegistro, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(123, 123, 123)
                        .addComponent(jbtnCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(bgLayout.createSequentialGroup()
                        .addComponent(jbtnCerrar, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(66, 66, 66)
                        .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 606, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))
                        .addGap(29, 29, 29)
                        .addComponent(jbtnReporteEmpleado1, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(bgLayout.createSequentialGroup()
                        .addGap(236, 236, 236)
                        .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(bgLayout.createSequentialGroup()
                                .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(bgLayout.createSequentialGroup()
                                        .addGap(230, 230, 230)
                                        .addComponent(jLabel1))
                                    .addComponent(jLabel3))
                                .addGap(233, 233, 233)
                                .addComponent(jLabel4))
                            .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(bgLayout.createSequentialGroup()
                                    .addComponent(jScrollPane3)
                                    .addGap(18, 18, 18)
                                    .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(bgLayout.createSequentialGroup()
                                            .addComponent(jtxtDate, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(6, 6, 6)
                                            .addComponent(jbtnFecha))
                                        .addGroup(bgLayout.createSequentialGroup()
                                            .addGap(11, 11, 11)
                                            .addComponent(jbtnBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 606, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(59, Short.MAX_VALUE))
        );
        bgLayout.setVerticalGroup(
            bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bgLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(time, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jbtnRegistro, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jbtnCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(bgLayout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(jLabel4)
                        .addGap(12, 12, 12))
                    .addGroup(bgLayout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(bgLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(bgLayout.createSequentialGroup()
                        .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(bgLayout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jtxtDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jbtnFecha, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(10, 10, 10)
                        .addComponent(jbtnBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(bgLayout.createSequentialGroup()
                        .addGap(105, 105, 105)
                        .addComponent(jbtnCerrar, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(bgLayout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(bgLayout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jbtnReporteEmpleado1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(bg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.PREFERRED_SIZE, 655, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jbtnCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnCerrarActionPerformed
        // TODO add your handling code here:
        FuncionesVentanas.abrirVentana(this, new Login());
    }//GEN-LAST:event_jbtnCerrarActionPerformed

    private void jbtnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnBuscarActionPerformed
        // TODO add your handling code here:
        SelectedDate fecha = date.getSelectedDate();
        String fechaBuscar = String.valueOf(fecha.getYear()) + "-" + String.valueOf(fecha.getMonth())
                + "-" + String.valueOf(fecha.getDay());
        cargarJornadas(jtblJornada1, "Mañana", fechaBuscar);
        cargarJornadas(jtblJornada2, "Tarde", fechaBuscar);
    }//GEN-LAST:event_jbtnBuscarActionPerformed

    private void jbtnFechaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnFechaActionPerformed
        // TODO add your handling code here:
        date.showPopup();
    }//GEN-LAST:event_jbtnFechaActionPerformed

    private void jbtnReporteEmpleado1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnReporteEmpleado1ActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_jbtnReporteEmpleado1ActionPerformed

    private void jbtnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnCancelarActionPerformed

    }//GEN-LAST:event_jbtnCancelarActionPerformed

    private void jbtnRegistroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnRegistroActionPerformed
        String tipo;
        LocalTime hora = LocalTime.of(7, 44);
        LocalTime hora2 = LocalTime.of(13, 15);
        LocalTime hora3 = LocalTime.of(13, 44);
        LocalTime hora4 = LocalTime.of(17, 15);
        System.out.println(usuarioDTO.verMarca(this.correo));
        System.out.println(!Boolean.parseBoolean(usuarioDTO.verMarca(this.correo)));
        if ((obtenerHoraActual().isAfter(hora) && obtenerHoraActual().isBefore(hora2))
                || (obtenerHoraActual().isAfter(hora3) && obtenerHoraActual().isBefore(hora4))) {
            if (!Boolean.parseBoolean(usuarioDTO.verMarca(this.correo))) {
                if (asistencia.comprobarRegistros(jornada(), obtenerFechaActual(), correo) == 0) {
                    tipo = "Entrada";
                    Registro registro = new Registro(this, this.correo, tipo);
                    registro.setVisible(true);
                } else {
                    FuncionesVentanas.mensaje(rootPane, "Ya existe un registro en esta jornada");
                }
            } else {
                tipo = "Salida";
                if (asistencia.registrarAsistencia(correo, obtenerFechaActual(), tipo, obtenerHoraActual2())
                        > 0) {
                    usuarioDTO.actualizarMarca("false", correo);
                    cambiarEstado();
                    cargarJornada();
                } else {
                    FuncionesVentanas.mensaje(rootPane, "No se pudo registrar su salida");
                }
            }
        } else {
            FuncionesVentanas.mensaje(rootPane, "Fuera de horario laboral");
        }
    }//GEN-LAST:event_jbtnRegistroActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        FlatMaterialLighterIJTheme.setup();
        UIManager.put("Button.arc", 999);

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new InterfazEmpleado().setVisible(true);
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel bg;
    private ec.edu.proyecto.componentes.dateChooser.DateChooser date;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JButton jbtnBuscar;
    private javax.swing.JButton jbtnCancelar;
    private javax.swing.JButton jbtnCerrar;
    private javax.swing.JButton jbtnFecha;
    private javax.swing.JButton jbtnRegistro;
    private javax.swing.JButton jbtnReporteEmpleado1;
    private javax.swing.JLabel jhora;
    private javax.swing.JTable jtblDatos;
    private javax.swing.JTable jtblJornada1;
    private javax.swing.JTable jtblJornada2;
    private javax.swing.JTextField jtxtDate;
    private javax.swing.JPanel time;
    // End of variables declaration//GEN-END:variables
}
