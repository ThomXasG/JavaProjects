/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package ec.edu.proyecto.interfaces;

import com.formdev.flatlaf.intellijthemes.materialthemeuilite.FlatMaterialLighterIJTheme;
import ec.edu.proyecto.datos.AsistenciaDTO;
import ec.edu.proyecto.datos.EmpleadoDTO;
import ec.edu.proyecto.datos.UsuarioDTO;
import ec.edu.proyecto.utilidades.FuncionesVentanas;
import java.time.ZonedDateTime;

/**
 *
 * @author Asus
 */
public class Registro extends javax.swing.JFrame {

    UsuarioDTO usuarioDTO = new UsuarioDTO();
    EmpleadoDTO empleadoDTO = new EmpleadoDTO();
    private Boolean asist = false;
    private InterfazEmpleado frame;
    private String correo;
    private String tipo;

    private AsistenciaDTO asistencia = new AsistenciaDTO();

    public String getCorreo() {
        return correo;
    }

    public Boolean getAsist() {
        return asist;
    }

    public Registro() {
        initComponents();
    }

    public Registro(InterfazEmpleado frame, String correo, String tipo) {
        initComponents();
        this.correo = correo;
        this.tipo = tipo;
        this.frame = frame;
    }

    private String obtenerHoraActual() {
        ZonedDateTime zonedDateTime = FuncionesVentanas.obtenerFechaHora();
        String hora = String.valueOf(zonedDateTime.getHour());
        String minuto = String.valueOf(zonedDateTime.getMinute());
        String segundo = String.valueOf(zonedDateTime.getSecond());
        minuto = (Integer.parseInt(minuto) < 10) ? "0" + minuto : minuto;
        segundo = (Integer.parseInt(segundo) < 10) ? "0" + segundo : segundo;

        String horaActual = hora + ":" + minuto + ":" + segundo;
        return horaActual;
    }

    private String obtenerFechaActual() {
        ZonedDateTime zonedDateTime = FuncionesVentanas.obtenerFechaHora();
        String anio = String.valueOf(zonedDateTime.getYear());
        String mes = String.valueOf(zonedDateTime.getMonthValue());
        String dia = String.valueOf(zonedDateTime.getDayOfMonth());
        return anio + "-" + mes + "-" + dia;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jtxtRegistro = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(26, 87, 172));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cedd.png"))); // NOI18N

        jLabel2.setFont(new java.awt.Font("Roboto", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(32, 115, 216));
        jLabel2.setText("Porfavor acerque su cedula al escaner para marcar su asistencia");

        jtxtRegistro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxtRegistroActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(42, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(29, 29, 29))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(197, 197, 197)
                        .addComponent(jLabel1))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(200, 200, 200)
                        .addComponent(jtxtRegistro, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel1)
                .addGap(27, 27, 27)
                .addComponent(jLabel2)
                .addGap(39, 39, 39)
                .addComponent(jtxtRegistro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(47, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        setSize(new java.awt.Dimension(493, 253));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jtxtRegistroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxtRegistroActionPerformed
        // TODO add your handling code here:
        if (empleadoDTO.obtenerIDigital(this.correo).equals(jtxtRegistro.getText())) {
            if (asistencia.registrarAsistencia(this.correo, obtenerFechaActual(), tipo, obtenerHoraActual()) > 0) {
                FuncionesVentanas.mensaje(rootPane, "Se ha registrado su asistencia");
                this.asist = true;
                this.frame.setVisible(false);
                this.setVisible(false);
                this.usuarioDTO.actualizarMarca("true", this.correo);
                InterfazEmpleado empleado = new InterfazEmpleado(correo);
                empleado.setVisible(true);
            } else {
                FuncionesVentanas.mensaje(rootPane, "Algo salio mal");
            }
        }else{
            FuncionesVentanas.mensaje(rootPane, "Id Digital incorrecto");
        }
    }//GEN-LAST:event_jtxtRegistroActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        FlatMaterialLighterIJTheme.setup();

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new Registro().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JTextField jtxtRegistro;
    // End of variables declaration//GEN-END:variables
}
