/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.proyecto.interfaces;

import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Asus
 */
public class main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Escribe una frase:");
        String texto = scanner.nextLine();

        long tiempoInicio = System.currentTimeMillis(); // Tiempo en milisegundos al inicio

        // Espera a que se ingrese la frase
        System.out.println("Escribe la misma frase para calcular la velocidad de tecleo:");
        String textoRepetido = scanner.nextLine();

        long tiempoFin = System.currentTimeMillis(); // Tiempo en milisegundos al final

        // Calcula la duración en milisegundos
        long duracion = tiempoFin - tiempoInicio;

        // Calcula la velocidad de tecleo en caracteres por segundo
        double velocidadTecleo = (double) texto.length() / (duracion / 1000.0);

        // Verifica si la velocidad es menor a 3 caracteres por segundo
        if (velocidadTecleo < 3.0) {
            System.out.println("Tu velocidad de tecleo es muy baja. No puedes continuar.");
        } else {
            System.out.println("Tardaste " + (duracion / 1000.0) + " segundos en escribir.");
            System.out.println("Tu velocidad de tecleo es de " + velocidadTecleo + " caracteres por segundo.");
        }
    }
}
