/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.proyecto.utilidades;

import ec.edu.proyecto.interfaces.InterfazAdministrador;
import ec.edu.proyecto.interfaces.InterfazEmpleado;
import java.awt.BorderLayout;
import java.awt.Component;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author Asus
 */
public class FuncionesVentanas {

    //TO DO: PARA CAMBIAR DE VENTAS
    public static void mostrarJPanel(JPanel panel, JPanel content) {
        panel.setSize(760, 650);
        panel.setLocation(0, 0);

        content.removeAll();
        content.add(panel, BorderLayout.CENTER);
        content.revalidate();
        content.repaint();
    }

    public static void mostrarJPanel(JPanel panel, JPanel content, int alto) {
        panel.setSize(760, alto);
        panel.setLocation(0, 0);

        content.removeAll();
        content.add(panel, BorderLayout.CENTER);
        content.revalidate();
        content.repaint();
    }

    public static void mostrarJPanel(JPanel panel, JPanel content, int ancho, int alto) {
        panel.setSize(ancho, alto);
        panel.setLocation(0, 0);

        content.removeAll();
        content.add(panel, BorderLayout.CENTER);
        content.revalidate();
        content.repaint();
    }

    public static void abrirVentana(JFrame ventana1, JFrame ventana2) {
        ventana1.dispose();
        ventana2.setVisible(true);
    }

    public static void abrirVentana(JFrame ventana1, InterfazAdministrador ventana2, String correo) {
        ventana1.dispose();
        ventana2.setCorreo(correo);
        ventana2.setVisible(true);
    }

    public static void abrirVentana(JFrame ventana1, InterfazEmpleado ventana2, String correo) {
        ventana1.dispose();
        ventana2.setCorreo(correo);
        ventana2.setVisible(true);
    }

    public static void mensaje(Component componente, String mensaje) {
        JOptionPane.showMessageDialog(componente, mensaje);
    }

    public static void limpiarCampos(JTextField... campos) {
        for (JTextField campo : campos) {
            campo.setText("");
        }
    }

    public static ZonedDateTime obtenerFechaHora() {
        ZoneId zoneId = ZoneId.of("America/Guayaquil");
        ZonedDateTime zonedDateTime = ZonedDateTime.now(zoneId);
        return zonedDateTime;
    }
}
