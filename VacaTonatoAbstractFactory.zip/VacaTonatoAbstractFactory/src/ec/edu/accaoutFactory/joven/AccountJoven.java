/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.accaoutFactory.joven;

import ec.edu.accaoutFactory.Account;

/**
 *
 * @author joelv
 */
public class AccountJoven implements Account{

    @Override
    public String Show() {
        return "Se creo la cuenta tipo Joven con interes del 1%";
    }
    
}
