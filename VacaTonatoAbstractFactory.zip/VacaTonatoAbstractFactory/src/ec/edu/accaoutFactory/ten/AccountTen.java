/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.accaoutFactory.ten;

import ec.edu.accaoutFactory.Account;

/**
 *
 * @author joelv
 */
public class AccountTen implements Account{

    @Override
    public String Show() {
        return "Se ha creado la cuenta tipo 10 con un interes deñ 1,5%";
    }
    
}
