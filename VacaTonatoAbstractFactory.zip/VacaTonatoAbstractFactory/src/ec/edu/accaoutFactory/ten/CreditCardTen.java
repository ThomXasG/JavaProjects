/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.accaoutFactory.ten;

import ec.edu.accaoutFactory.CreditCard;

/**
 *
 * @author joelv
 */
public class CreditCardTen implements CreditCard{

    @Override
    public String Show() {
        return "Se ha creado una tarjeta de credito tipo 10 con importe de $10 y con monto maximo de $2000";
    }
    
}
