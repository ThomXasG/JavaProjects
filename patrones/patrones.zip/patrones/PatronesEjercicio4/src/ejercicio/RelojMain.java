/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicio;

/**
 *
 * @author Asus
 */
public class RelojMain {
    public static void main(String[] args) {
        Clock reloj = Clock.getInstance();
        reloj.startClock();
    }
}
