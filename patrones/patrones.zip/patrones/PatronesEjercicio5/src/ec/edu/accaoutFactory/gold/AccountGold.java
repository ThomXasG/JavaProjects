/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.accaoutFactory.gold;

import ec.edu.accaoutFactory.Account;

/**
 *
 * @author joelv
 */
public class AccountGold implements Account{

    @Override
    public String Show() {
        return "Se ha creado una cuenta tipo Oro con el 2% de interes";
    }
    
}
