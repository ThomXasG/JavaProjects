/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.accaoutFactory.standar;

import ec.edu.accaoutFactory.Account;

/**
 *
 * @author Asus
 */
public class AccountStandar implements Account{

    @Override
    public String Show() {
        return "Se ha creado su cuenta estandar con el 0.5% de interes";
    }
    
}
