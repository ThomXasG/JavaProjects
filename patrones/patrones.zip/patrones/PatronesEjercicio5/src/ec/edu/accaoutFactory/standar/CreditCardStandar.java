/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.accaoutFactory.standar;

import ec.edu.accaoutFactory.CreditCard;

/**
 *
 * @author Asus
 */
public class CreditCardStandar implements CreditCard{

    @Override
    public String Show() {
        return "No correspon a una tarjeta de credito";
    }
    
}
