/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.accaoutFactory.standar;

import ec.edu.accaoutFactory.DebitCard;

/**
 *
 * @author Asus
 */
public class DebitCardStandar implements DebitCard{

    @Override
    public String Show() {
        return "Se ha creado su tarjeta de debito estandar con 5 euros";
    }
    
}
