/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.accaoutFactory.standar;

import ec.edu.accaoutFactory.Gift;

/**
 *
 * @author Asus
 */
public class GiftStandar implements Gift{

    @Override
    public String show() {
        return "No corresponde a un regalo";
    }
    
}
